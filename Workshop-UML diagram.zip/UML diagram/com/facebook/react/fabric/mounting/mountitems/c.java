package com.facebook.react.fabric.mounting.mountitems;

/* compiled from: DispatchCommandMountItem */
public abstract class c implements g {
    private int a = 0;

    public int b() {
        return this.a;
    }

    public void c() {
        this.a++;
    }
}
