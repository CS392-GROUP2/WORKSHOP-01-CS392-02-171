package com.facebook.react.fabric.mounting.mountitems;

import vigqyno.C0201;

/* compiled from: RemoveMountItem */
public class j implements g {
    private int a;
    private int b;
    private int c;

    public j(int i, int i2, int i3) {
        this.a = i;
        this.b = i2;
        this.c = i3;
    }

    @Override // com.facebook.react.fabric.mounting.mountitems.g
    public void a(jj0 jj0) {
        jj0.k(this.b, this.c);
        throw null;
    }

    public String toString() {
        return C0201.m82(36236) + this.a + C0201.m82(36237) + this.b + C0201.m82(36238) + this.c;
    }
}
