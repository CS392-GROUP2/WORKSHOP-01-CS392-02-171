package com.facebook.react.fabric.mounting.mountitems;

import vigqyno.C0201;

/* compiled from: UpdatePaddingMountItem */
public class o implements g {
    private final int a;
    private final int b;
    private final int c;
    private final int d;
    private final int e;

    public o(int i, int i2, int i3, int i4, int i5) {
        this.a = i;
        this.b = i2;
        this.c = i3;
        this.d = i4;
        this.e = i5;
    }

    @Override // com.facebook.react.fabric.mounting.mountitems.g
    public void a(jj0 jj0) {
        jj0.q(this.a, this.b, this.c, this.d, this.e);
        throw null;
    }

    public String toString() {
        return C0201.m82(34560) + this.a + C0201.m82(34561) + this.b + C0201.m82(34562) + this.c + C0201.m82(34563) + this.d + C0201.m82(34564) + this.e;
    }
}
