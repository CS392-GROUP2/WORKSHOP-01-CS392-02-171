package com.facebook.react.fabric.mounting.mountitems;

/* compiled from: MountItem */
public interface g {
    void a(jj0 jj0);
}
