package com.facebook.react.fabric.mounting.mountitems;

import com.facebook.react.uimanager.j0;
import vigqyno.C0201;

/* compiled from: UpdateStateMountItem */
public class q implements g {
    private final int a;
    private final j0 b;

    public q(int i, j0 j0Var) {
        this.a = i;
        this.b = j0Var;
    }

    @Override // com.facebook.react.fabric.mounting.mountitems.g
    public void a(jj0 jj0) {
        jj0.s(this.a, this.b);
        throw null;
    }

    public String toString() {
        return C0201.m82(35063) + this.a + C0201.m82(35064);
    }
}
