package com.facebook.react.fabric.mounting.mountitems;

import vigqyno.C0201;

/* compiled from: DeleteMountItem */
public class b implements g {
    private int a;

    public b(int i) {
        this.a = i;
    }

    @Override // com.facebook.react.fabric.mounting.mountitems.g
    public void a(jj0 jj0) {
        jj0.e(this.a);
        throw null;
    }

    public String toString() {
        return C0201.m82(35599) + this.a + C0201.m82(35600);
    }
}
