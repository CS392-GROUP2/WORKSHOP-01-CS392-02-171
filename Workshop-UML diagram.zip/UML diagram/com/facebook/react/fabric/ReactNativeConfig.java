package com.facebook.react.fabric;

@zh0
public interface ReactNativeConfig {
}
