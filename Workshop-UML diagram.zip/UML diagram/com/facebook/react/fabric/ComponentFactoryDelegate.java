package com.facebook.react.fabric;

import com.facebook.jni.HybridData;

@zh0
public class ComponentFactoryDelegate {
    @zh0
    private final HybridData mHybridData = initHybrid();

    static {
        b.a();
    }

    @zh0
    private static native HybridData initHybrid();
}
