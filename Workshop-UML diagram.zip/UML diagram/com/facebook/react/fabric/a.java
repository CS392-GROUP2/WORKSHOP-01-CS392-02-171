package com.facebook.react.fabric;

import java.util.HashMap;
import java.util.Map;
import vigqyno.C0201;

/* compiled from: FabricComponents */
public class a {
    private static final Map<String, String> a;

    static {
        HashMap hashMap = new HashMap();
        a = hashMap;
        hashMap.put(C0201.m82(16944), C0201.m82(16945));
        a.put(C0201.m82(16946), C0201.m82(16947));
        a.put(C0201.m82(16948), C0201.m82(16949));
        a.put(C0201.m82(16950), C0201.m82(16951));
        a.put(C0201.m82(16952), C0201.m82(16953));
        a.put(C0201.m82(16954), C0201.m82(16955));
        a.put(C0201.m82(16956), C0201.m82(16957));
        a.put(C0201.m82(16958), C0201.m82(16959));
        a.put(C0201.m82(16960), C0201.m82(16961));
        a.put(C0201.m82(16962), C0201.m82(16963));
        a.put(C0201.m82(16964), C0201.m82(16965));
        a.put(C0201.m82(16966), C0201.m82(16967));
        a.put(C0201.m82(16968), C0201.m82(16969));
        a.put(C0201.m82(16970), C0201.m82(16971));
        a.put(C0201.m82(16972), C0201.m82(16973));
        a.put(C0201.m82(16974), C0201.m82(16975));
    }

    public static String a(String str) {
        String str2 = a.get(str);
        return str2 != null ? str2 : str;
    }
}
