package com.facebook.react.fabric;

import com.facebook.react.modules.core.a;

/* compiled from: GuardedFrameCallback */
public abstract class d extends a.AbstractC0040a {
}
