package com.facebook.react.turbomodule.core.interfaces;

/* compiled from: TurboModule */
public interface a {
}
