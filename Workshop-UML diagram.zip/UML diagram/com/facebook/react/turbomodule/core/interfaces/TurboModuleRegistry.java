package com.facebook.react.turbomodule.core.interfaces;

import java.util.Collection;
import java.util.List;

public interface TurboModuleRegistry {
    List<String> a();

    a b(String str);

    Collection<a> c();

    boolean d(String str);
}
