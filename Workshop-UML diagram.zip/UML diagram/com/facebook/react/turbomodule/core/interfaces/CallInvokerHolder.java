package com.facebook.react.turbomodule.core.interfaces;

public interface CallInvokerHolder {
}
