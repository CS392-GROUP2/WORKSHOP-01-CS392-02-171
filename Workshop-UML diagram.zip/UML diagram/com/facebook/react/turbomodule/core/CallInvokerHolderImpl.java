package com.facebook.react.turbomodule.core;

import com.facebook.react.turbomodule.core.interfaces.CallInvokerHolder;

public class CallInvokerHolderImpl implements CallInvokerHolder {
}
