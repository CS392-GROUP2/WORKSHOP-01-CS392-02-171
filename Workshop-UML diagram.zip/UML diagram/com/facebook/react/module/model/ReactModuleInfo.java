package com.facebook.react.module.model;

public class ReactModuleInfo {
    private final String a;
    private final boolean b;
    private final boolean c;
    private final boolean d;
    private final boolean e;
    private String f;
    private final boolean g;

    public ReactModuleInfo(String str, String str2, boolean z, boolean z2, boolean z3, boolean z4, boolean z5) {
        this.a = str;
        this.f = str2;
        this.b = z;
        this.c = z2;
        this.d = z3;
        this.e = z4;
        this.g = z5;
    }

    public boolean a() {
        return this.b;
    }

    public String b() {
        return this.f;
    }

    public boolean c() {
        return this.d;
    }

    public boolean d() {
        return this.e;
    }

    public boolean e() {
        return this.g;
    }

    public String f() {
        return this.a;
    }

    public boolean g() {
        return this.c;
    }
}
