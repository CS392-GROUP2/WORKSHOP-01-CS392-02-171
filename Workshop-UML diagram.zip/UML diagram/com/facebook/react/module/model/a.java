package com.facebook.react.module.model;

import java.util.Map;

/* compiled from: ReactModuleInfoProvider */
public interface a {
    Map<String, ReactModuleInfo> a();
}
