package com.facebook.react.modules.timepicker;

/* compiled from: TimePickerMode */
public enum c {
    CLOCK,
    SPINNER,
    DEFAULT
}
