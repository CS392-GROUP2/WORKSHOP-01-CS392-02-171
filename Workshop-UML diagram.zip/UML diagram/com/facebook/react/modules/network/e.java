package com.facebook.react.modules.network;

import okhttp3.Interceptor;

/* compiled from: NetworkInterceptorCreator */
public interface e {
    Interceptor create();
}
