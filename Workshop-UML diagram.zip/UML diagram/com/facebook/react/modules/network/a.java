package com.facebook.react.modules.network;

import okhttp3.CookieJar;

/* compiled from: CookieJarContainer */
public interface a extends CookieJar {
    void a();

    void b(CookieJar cookieJar);
}
