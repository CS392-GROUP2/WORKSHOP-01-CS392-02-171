package com.facebook.react.modules.network;

import okhttp3.OkHttpClient;

/* compiled from: OkHttpClientFactory */
public interface f {
    OkHttpClient a();
}
