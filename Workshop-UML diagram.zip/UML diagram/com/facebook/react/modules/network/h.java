package com.facebook.react.modules.network;

/* compiled from: ProgressListener */
public interface h {
    void a(long j, long j2, boolean z);
}
