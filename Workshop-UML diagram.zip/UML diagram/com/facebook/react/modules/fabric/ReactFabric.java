package com.facebook.react.modules.fabric;

import com.facebook.react.bridge.JavaScriptModule;

public interface ReactFabric extends JavaScriptModule {
    void unmountComponentAtNode(int i);
}
