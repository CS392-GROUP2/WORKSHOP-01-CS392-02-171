package com.facebook.react.modules.core;

/* compiled from: PermissionListener */
public interface f {
    boolean onRequestPermissionsResult(int i, String[] strArr, int[] iArr);
}
