package com.facebook.react.modules.core;

/* compiled from: DefaultHardwareBackBtnHandler */
public interface b {
    void c();
}
