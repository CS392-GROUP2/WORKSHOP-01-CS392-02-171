package com.facebook.react.modules.core;

/* compiled from: PermissionAwareActivity */
public interface e {
    void i(String[] strArr, int i, f fVar);

    boolean shouldShowRequestPermissionRationale(String str);
}
