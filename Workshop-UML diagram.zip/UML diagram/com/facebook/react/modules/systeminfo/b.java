package com.facebook.react.modules.systeminfo;

import com.facebook.react.common.e;
import java.util.Map;
import vigqyno.C0201;

/* compiled from: ReactNativeVersion */
public class b {
    public static final Map<String, Object> a = e.g(C0201.m82(8272), 0, C0201.m82(8273), 63, C0201.m82(8274), 3, C0201.m82(8275), null);
}
