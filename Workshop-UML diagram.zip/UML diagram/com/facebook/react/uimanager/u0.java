package com.facebook.react.uimanager;

/* compiled from: UIManagerReanimatedHelper */
public class u0 {
    public static boolean a(o0 o0Var) {
        return o0Var.r().X();
    }
}
