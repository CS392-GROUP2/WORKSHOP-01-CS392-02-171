package com.facebook.react.uimanager;

import com.facebook.react.bridge.ReadableNativeMap;
import com.facebook.react.bridge.WritableMap;

/* compiled from: StateWrapper */
public interface j0 {
    void a(WritableMap writableMap);

    ReadableNativeMap getState();
}
