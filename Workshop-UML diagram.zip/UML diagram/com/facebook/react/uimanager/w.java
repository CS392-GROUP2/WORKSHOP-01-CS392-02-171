package com.facebook.react.uimanager;

/* compiled from: ReactCompoundViewGroup */
public interface w extends v {
    boolean d(float f, float f2);
}
