package com.facebook.react.uimanager;

/* compiled from: UIBlock */
public interface n0 {
    void a(m mVar);
}
