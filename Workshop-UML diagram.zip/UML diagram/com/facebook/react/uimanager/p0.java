package com.facebook.react.uimanager;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.uimanager.events.d;

@Deprecated
/* compiled from: UIImplementationProvider */
public class p0 {
    public o0 a(ReactApplicationContext reactApplicationContext, a1 a1Var, d dVar, int i) {
        return new o0(reactApplicationContext, a1Var, dVar, i);
    }
}
