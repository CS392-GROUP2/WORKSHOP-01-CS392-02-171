package com.facebook.react.uimanager;

/* compiled from: ReactCompoundView */
public interface v {
    int b(float f, float f2);
}
