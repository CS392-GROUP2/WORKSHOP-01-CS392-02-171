package com.facebook.react.uimanager;

import android.view.View;

/* compiled from: ViewManagerDelegate */
public interface y0<T extends View> {
    void a(T t, String str, Object obj);
}
