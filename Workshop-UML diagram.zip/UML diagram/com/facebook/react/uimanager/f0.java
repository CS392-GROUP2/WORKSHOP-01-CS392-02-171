package com.facebook.react.uimanager;

import android.view.MotionEvent;

/* compiled from: RootView */
public interface f0 {
    void c(Throwable th);

    void g(MotionEvent motionEvent);
}
