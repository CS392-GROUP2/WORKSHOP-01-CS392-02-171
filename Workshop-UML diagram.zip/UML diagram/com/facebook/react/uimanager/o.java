package com.facebook.react.uimanager;

/* compiled from: NoSuchNativeViewException */
public class o extends g {
    public o(String str) {
        super(str);
    }
}
