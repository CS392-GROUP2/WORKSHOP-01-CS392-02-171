package com.facebook.react.uimanager;

/* compiled from: ReactZIndexedViewGroup */
public interface e0 {
    int getZIndexMappedChildIndex(int i);

    void updateDrawingOrder();
}
