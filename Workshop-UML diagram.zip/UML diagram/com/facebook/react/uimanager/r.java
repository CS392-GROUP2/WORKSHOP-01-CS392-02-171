package com.facebook.react.uimanager;

/* compiled from: PointerEvents */
public enum r {
    NONE,
    BOX_NONE,
    BOX_ONLY,
    AUTO
}
