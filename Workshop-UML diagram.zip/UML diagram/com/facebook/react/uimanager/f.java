package com.facebook.react.uimanager;

/* compiled from: IViewManagerWithChildren */
public interface f {
    boolean needsCustomLayoutForChildren();
}
