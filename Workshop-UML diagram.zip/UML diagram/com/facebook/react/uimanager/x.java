package com.facebook.react.uimanager;

/* compiled from: ReactPointerEventsView */
public interface x {
    r getPointerEvents();
}
