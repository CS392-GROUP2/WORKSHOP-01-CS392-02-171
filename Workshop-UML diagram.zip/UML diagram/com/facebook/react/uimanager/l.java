package com.facebook.react.uimanager;

/* compiled from: NativeKind */
public enum l {
    PARENT,
    LEAF,
    NONE
}
