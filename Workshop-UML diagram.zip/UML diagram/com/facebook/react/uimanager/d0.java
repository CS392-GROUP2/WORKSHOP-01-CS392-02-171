package com.facebook.react.uimanager;

import com.facebook.yoga.c;
import com.facebook.yoga.d;

/* compiled from: ReactYogaConfigProvider */
public class d0 {
    private static c a;

    public static c a() {
        if (a == null) {
            c a2 = d.a();
            a = a2;
            a2.a(0.0f);
            a.b(true);
        }
        return a;
    }
}
