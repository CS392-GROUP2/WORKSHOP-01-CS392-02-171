package com.facebook.react.uimanager;

/* compiled from: UIManagerModuleListener */
public interface t0 {
    void willDispatchViewUpdates(UIManagerModule uIManagerModule);
}
