package com.facebook.react.uimanager.events;

/* compiled from: BatchEventDispatchedListener */
public interface a {
    void a();
}
