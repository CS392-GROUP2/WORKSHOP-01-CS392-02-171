package com.facebook.react.uimanager.events;

/* compiled from: EventDispatcherListener */
public interface e {
    void a(c cVar);
}
