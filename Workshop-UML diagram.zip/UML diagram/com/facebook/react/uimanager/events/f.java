package com.facebook.react.uimanager.events;

import android.view.MotionEvent;
import android.view.View;
import com.facebook.react.uimanager.g0;

/* compiled from: NativeGestureUtil */
public class f {
    public static void a(View view, MotionEvent motionEvent) {
        g0.a(view).g(motionEvent);
    }
}
