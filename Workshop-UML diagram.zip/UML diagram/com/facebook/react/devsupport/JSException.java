package com.facebook.react.devsupport;

@zh0
public class JSException extends Exception {
    @zh0
    public JSException(String str, String str2, Throwable th) {
        super(str, th);
    }
}
