package com.facebook.react.devsupport;

import android.view.View;
import com.facebook.react.bridge.DefaultNativeModuleCallExceptionHandler;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import vigqyno.C0201;

/* compiled from: DisabledDevSupportManager */
public class b implements gj0 {
    private final DefaultNativeModuleCallExceptionHandler a = new DefaultNativeModuleCallExceptionHandler();

    @Override // defpackage.gj0
    public View a(String str) {
        return null;
    }

    @Override // defpackage.gj0
    public boolean b() {
        return false;
    }

    @Override // defpackage.gj0
    public void c(boolean z) {
    }

    @Override // defpackage.gj0
    public void d() {
    }

    @Override // defpackage.gj0
    public void e(ReactContext reactContext) {
    }

    @Override // defpackage.gj0
    public void f() {
    }

    @Override // defpackage.gj0
    public void g(String str, ReadableArray readableArray, int i) {
    }

    @Override // defpackage.gj0
    public void h(boolean z) {
    }

    @Override // com.facebook.react.bridge.NativeModuleCallExceptionHandler
    public void handleException(Exception exc) {
        f60.j(C0201.m82(38342), C0201.m82(38343), exc);
        this.a.handleException(exc);
    }

    @Override // defpackage.gj0
    public void i(String str, fj0 fj0) {
    }

    @Override // defpackage.gj0
    public void j(View view) {
    }

    @Override // defpackage.gj0
    public void k(boolean z) {
    }

    @Override // defpackage.gj0
    public void l(boolean z) {
    }

    @Override // defpackage.gj0
    public qj0 m() {
        return null;
    }

    @Override // defpackage.gj0
    public void n() {
    }

    @Override // defpackage.gj0
    public void o() {
    }

    @Override // defpackage.gj0
    public void p() {
    }

    @Override // defpackage.gj0
    public void q(ReactContext reactContext) {
    }

    @Override // defpackage.gj0
    public void r(String str, ReadableArray readableArray, int i) {
    }

    @Override // defpackage.gj0
    public void s(hj0 hj0) {
    }
}
