package com.facebook.react.devsupport;

/* compiled from: RedBoxHandler */
public interface f {
}
