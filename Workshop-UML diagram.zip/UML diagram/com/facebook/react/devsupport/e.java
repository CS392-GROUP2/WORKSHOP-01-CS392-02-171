package com.facebook.react.devsupport;

/* compiled from: ReactInstanceManagerDevHelper */
public interface e {
}
