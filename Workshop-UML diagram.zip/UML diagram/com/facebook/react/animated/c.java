package com.facebook.react.animated;

/* compiled from: AnimatedNodeValueListener */
public interface c {
    void a(double d);
}
