package com.facebook.react.animated;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.JSApplicationCausedNativeException;
import com.facebook.react.bridge.ReadableMap;
import vigqyno.C0201;

/* compiled from: AnimationDriver */
public abstract class d {
    public boolean a = false;
    public s b;
    public Callback c;
    public int d;

    public void a(ReadableMap readableMap) {
        throw new JSApplicationCausedNativeException(C0201.m82(28966) + getClass().getSimpleName() + C0201.m82(28967));
    }

    public abstract void b(long j);
}
