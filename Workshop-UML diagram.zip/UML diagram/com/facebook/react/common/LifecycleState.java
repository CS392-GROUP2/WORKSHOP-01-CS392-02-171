package com.facebook.react.common;

public enum LifecycleState {
    BEFORE_CREATE,
    BEFORE_RESUME,
    RESUMED
}
