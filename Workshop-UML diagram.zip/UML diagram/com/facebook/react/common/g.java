package com.facebook.react.common;

import java.nio.charset.Charset;
import vigqyno.C0201;

/* compiled from: StandardCharsets */
public class g {
    public static final Charset a = Charset.forName(C0201.m82(29328));

    static {
        Charset.forName(C0201.m82(29329));
        Charset.forName(C0201.m82(29330));
        Charset.forName(C0201.m82(29331));
    }
}
