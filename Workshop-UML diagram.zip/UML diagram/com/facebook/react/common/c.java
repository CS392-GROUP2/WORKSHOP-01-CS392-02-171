package com.facebook.react.common;

/* compiled from: JavascriptException */
public class c extends RuntimeException {
    public c(String str) {
        super(str);
    }

    public c a(String str) {
        return this;
    }
}
