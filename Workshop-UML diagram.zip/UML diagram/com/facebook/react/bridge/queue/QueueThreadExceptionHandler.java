package com.facebook.react.bridge.queue;

public interface QueueThreadExceptionHandler {
    void handleException(Exception exc);
}
