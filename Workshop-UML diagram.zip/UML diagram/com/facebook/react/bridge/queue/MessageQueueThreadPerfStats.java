package com.facebook.react.bridge.queue;

public class MessageQueueThreadPerfStats {
    public long cpuTime;
    public long wallTime;
}
