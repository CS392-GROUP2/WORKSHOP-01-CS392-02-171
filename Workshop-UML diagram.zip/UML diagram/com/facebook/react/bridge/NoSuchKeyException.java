package com.facebook.react.bridge;

@zh0
public class NoSuchKeyException extends RuntimeException {
    @zh0
    public NoSuchKeyException(String str) {
        super(str);
    }
}
