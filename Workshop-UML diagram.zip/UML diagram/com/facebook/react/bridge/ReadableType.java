package com.facebook.react.bridge;

@zh0
public enum ReadableType {
    Null,
    Boolean,
    Number,
    String,
    Map,
    Array
}
