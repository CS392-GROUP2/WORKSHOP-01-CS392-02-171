package com.facebook.react.bridge;

@zh0
public class UnexpectedNativeTypeException extends RuntimeException {
    @zh0
    public UnexpectedNativeTypeException(String str) {
        super(str);
    }
}
