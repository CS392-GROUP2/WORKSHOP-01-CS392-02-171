package com.facebook.react.bridge;

@zh0
public interface JavaScriptModule {
}
