package com.facebook.react.bridge;

@zh0
public class InvalidIteratorException extends RuntimeException {
    @zh0
    public InvalidIteratorException(String str) {
        super(str);
    }
}
