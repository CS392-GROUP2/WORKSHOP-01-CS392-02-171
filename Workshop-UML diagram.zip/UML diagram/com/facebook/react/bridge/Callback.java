package com.facebook.react.bridge;

public interface Callback {
    void invoke(Object... objArr);
}
