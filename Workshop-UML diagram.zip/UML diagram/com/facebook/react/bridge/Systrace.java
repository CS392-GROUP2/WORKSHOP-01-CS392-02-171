package com.facebook.react.bridge;

@zh0
public interface Systrace extends JavaScriptModule {
    @zh0
    void setEnabled(boolean z);
}
