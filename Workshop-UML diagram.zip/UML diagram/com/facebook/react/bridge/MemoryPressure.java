package com.facebook.react.bridge;

public enum MemoryPressure {
    UI_HIDDEN,
    MODERATE,
    CRITICAL
}
