package com.facebook.react.bridge;

@zh0
public interface ReadableMapKeySetIterator {
    boolean hasNextKey();

    String nextKey();
}
