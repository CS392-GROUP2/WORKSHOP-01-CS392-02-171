package com.facebook.react.bridge;

public interface OnBatchCompleteListener {
    void onBatchComplete();
}
