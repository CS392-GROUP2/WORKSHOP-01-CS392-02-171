package com.facebook.react.bridge;

public interface NativeModuleCallExceptionHandler {
    void handleException(Exception exc);
}
