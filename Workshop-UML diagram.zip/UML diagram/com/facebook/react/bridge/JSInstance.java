package com.facebook.react.bridge;

public interface JSInstance {
    void invokeCallback(int i, NativeArrayInterface nativeArrayInterface);
}
