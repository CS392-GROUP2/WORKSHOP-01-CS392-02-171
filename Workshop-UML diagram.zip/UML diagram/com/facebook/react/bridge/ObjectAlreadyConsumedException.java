package com.facebook.react.bridge;

@zh0
public class ObjectAlreadyConsumedException extends RuntimeException {
    @zh0
    public ObjectAlreadyConsumedException(String str) {
        super(str);
    }
}
