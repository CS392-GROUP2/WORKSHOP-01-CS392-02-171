package com.facebook.react.bridge;

public interface NativeArrayInterface {
    String toString();
}
