package com.facebook.react.bridge;

public enum JSIModuleType {
    TurboModuleManager,
    UIManager
}
