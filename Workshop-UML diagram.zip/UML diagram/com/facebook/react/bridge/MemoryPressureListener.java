package com.facebook.react.bridge;

public interface MemoryPressureListener {
    void handleMemoryPressure(int i);
}
