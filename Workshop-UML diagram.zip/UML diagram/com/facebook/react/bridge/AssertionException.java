package com.facebook.react.bridge;

public class AssertionException extends RuntimeException {
    public AssertionException(String str) {
        super(str);
    }
}
