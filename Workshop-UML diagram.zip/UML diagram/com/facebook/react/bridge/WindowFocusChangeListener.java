package com.facebook.react.bridge;

public interface WindowFocusChangeListener {
    void onWindowFocusChange(boolean z);
}
