package com.facebook.hermes.reactexecutor;

/* compiled from: RuntimeConfig */
public final class b {
    public long a;
    public boolean b;
}
