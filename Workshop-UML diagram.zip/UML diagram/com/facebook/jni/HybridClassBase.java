package com.facebook.jni;

import com.facebook.jni.annotations.DoNotStrip;

@DoNotStrip
public abstract class HybridClassBase extends HybridData {
}
