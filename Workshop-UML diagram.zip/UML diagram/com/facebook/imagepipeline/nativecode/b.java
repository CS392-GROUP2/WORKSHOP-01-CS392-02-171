package com.facebook.imagepipeline.nativecode;

import com.facebook.soloader.SoLoader;
import vigqyno.C0201;

/* compiled from: NativeFiltersLoader */
public class b {
    public static void a() {
        SoLoader.j(C0201.m82(32751));
    }
}
