package com.facebook.imagepipeline.nativecode;

import com.facebook.soloader.SoLoader;
import java.util.ArrayList;
import java.util.Collections;
import vigqyno.C0201;

/* compiled from: ImagePipelineNativeLoader */
public class a {
    static {
        Collections.unmodifiableList(new ArrayList());
    }

    public static void a() {
        SoLoader.j(C0201.m82(32793));
    }
}
