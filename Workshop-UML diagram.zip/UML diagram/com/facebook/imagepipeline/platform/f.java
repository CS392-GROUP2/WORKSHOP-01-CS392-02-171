package com.facebook.imagepipeline.platform;

import android.graphics.Bitmap;
import android.graphics.ColorSpace;
import android.graphics.Rect;

/* compiled from: PlatformDecoder */
public interface f {
    v60<Bitmap> a(af0 af0, Bitmap.Config config, Rect rect, ColorSpace colorSpace);

    v60<Bitmap> b(af0 af0, Bitmap.Config config, Rect rect, int i);

    v60<Bitmap> c(af0 af0, Bitmap.Config config, Rect rect, int i, ColorSpace colorSpace);
}
