package com.facebook.common.time;

/* compiled from: MonotonicClock */
public interface b {
    @u50
    long now();
}
