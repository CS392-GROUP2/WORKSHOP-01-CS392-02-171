package com.facebook.common.time;

/* compiled from: Clock */
public interface a {
    long now();
}
