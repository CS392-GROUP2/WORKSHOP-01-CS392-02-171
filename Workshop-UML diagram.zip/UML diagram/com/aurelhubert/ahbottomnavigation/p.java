package com.aurelhubert.ahbottomnavigation;

/* compiled from: lambda */
public final /* synthetic */ class p implements Runnable {
    public final /* synthetic */ q a;

    public /* synthetic */ p(q qVar) {
        this.a = qVar;
    }

    public final void run() {
        this.a.requestLayout();
    }
}
