package com.aurelhubert.ahbottomnavigation;

import vigqyno.C0201;

public final class x {
    public static final int abc_action_bar_title_item = 0;
    public static final int abc_action_bar_up_container = 0;
    public static final int abc_action_menu_item_layout = 0;
    public static final int abc_action_menu_layout = 0;
    public static final int abc_action_mode_bar = 0;
    public static final int abc_action_mode_close_item_material = 0;
    public static final int abc_activity_chooser_view = 0;
    public static final int abc_activity_chooser_view_list_item = 0;
    public static final int abc_alert_dialog_button_bar_material = 0;
    public static final int abc_alert_dialog_material = 0;
    public static final int abc_alert_dialog_title_material = 0;
    public static final int abc_cascading_menu_item_layout = 0;
    public static final int abc_dialog_title_material = 0;
    public static final int abc_expanded_menu_layout = 0;
    public static final int abc_list_menu_item_checkbox = 0;
    public static final int abc_list_menu_item_icon = 0;
    public static final int abc_list_menu_item_layout = 0;
    public static final int abc_list_menu_item_radio = 0;
    public static final int abc_popup_menu_header_item_layout = 0;
    public static final int abc_popup_menu_item_layout = 0;
    public static final int abc_screen_content_include = 0;
    public static final int abc_screen_simple = 0;
    public static final int abc_screen_simple_overlay_action_mode = 0;
    public static final int abc_screen_toolbar = 0;
    public static final int abc_search_dropdown_item_icons_2line = 0;
    public static final int abc_search_view = 0;
    public static final int abc_select_dialog_material = 0;
    public static final int abc_tooltip = 0;
    public static final int bottom_navigation_item = 0;
    public static final int bottom_navigation_small_item = 0;
    public static final int design_bottom_navigation_item = 0;
    public static final int design_bottom_sheet_dialog = 0;
    public static final int design_layout_snackbar = 0;
    public static final int design_layout_snackbar_include = 0;
    public static final int design_layout_tab_icon = 0;
    public static final int design_layout_tab_text = 0;
    public static final int design_menu_item_action_area = 0;
    public static final int design_navigation_item = 0;
    public static final int design_navigation_item_header = 0;
    public static final int design_navigation_item_separator = 0;
    public static final int design_navigation_item_subheader = 0;
    public static final int design_navigation_menu = 0;
    public static final int design_navigation_menu_item = 0;
    public static final int mtrl_layout_snackbar = 0;
    public static final int mtrl_layout_snackbar_include = 0;
    public static final int notification_action = 0;
    public static final int notification_action_tombstone = 0;
    public static final int notification_template_custom_big = 0;
    public static final int notification_template_icon_group = 0;
    public static final int notification_template_part_chronometer = 0;
    public static final int notification_template_part_time = 0;
    public static final int select_dialog_item_material = 0;
    public static final int select_dialog_multichoice_material = 0;
    public static final int select_dialog_singlechoice_material = 0;
    public static final int support_simple_spinner_dropdown_item = 0;

    static {
        C0201.m83(x.class, 191);
    }
}
