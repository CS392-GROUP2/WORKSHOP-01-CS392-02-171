package com.bumptech.glide;

import vigqyno.C0201;

public final class h {
    public static final int action_container = 0;
    public static final int action_divider = 0;
    public static final int action_image = 0;
    public static final int action_text = 0;
    public static final int actions = 0;
    public static final int async = 0;
    public static final int blocking = 0;
    public static final int bottom = 0;
    public static final int chronometer = 0;
    public static final int end = 0;
    public static final int forever = 0;
    public static final int glide_custom_view_target_tag = 0;
    public static final int icon = 0;
    public static final int icon_group = 0;
    public static final int info = 0;
    public static final int italic = 0;
    public static final int left = 0;
    public static final int line1 = 0;
    public static final int line3 = 0;
    public static final int none = 0;
    public static final int normal = 0;
    public static final int notification_background = 0;
    public static final int notification_main_column = 0;
    public static final int notification_main_column_container = 0;
    public static final int right = 0;
    public static final int right_icon = 0;
    public static final int right_side = 0;
    public static final int start = 0;
    public static final int tag_transition_group = 0;
    public static final int tag_unhandled_key_event_manager = 0;
    public static final int tag_unhandled_key_listeners = 0;
    public static final int text = 0;
    public static final int text2 = 0;
    public static final int time = 0;
    public static final int title = 0;
    public static final int top = 0;

    static {
        C0201.m83(h.class, 308);
    }
}
