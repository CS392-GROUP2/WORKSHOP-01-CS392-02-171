package com.bumptech.glide;

import android.content.Context;
import com.dylanvann.fastimage.k;
import defpackage.gn;

/* compiled from: GeneratedRequestManagerFactory */
public final class a implements gn.b {
    @Override // defpackage.gn.b
    public k a(c cVar, cn cnVar, hn hnVar, Context context) {
        return new k(cVar, cnVar, hnVar, context);
    }
}
