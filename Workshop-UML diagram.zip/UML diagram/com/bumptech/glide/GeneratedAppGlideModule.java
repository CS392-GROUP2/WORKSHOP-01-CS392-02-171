package com.bumptech.glide;

import defpackage.gn;
import java.util.Set;

public abstract class GeneratedAppGlideModule extends ln {
    public abstract Set<Class<?>> d();

    public gn.b e() {
        return null;
    }
}
