package com.bumptech.glide.load;

/* compiled from: DataSource */
public enum a {
    LOCAL,
    REMOTE,
    DATA_DISK_CACHE,
    RESOURCE_DISK_CACHE,
    MEMORY_CACHE
}
