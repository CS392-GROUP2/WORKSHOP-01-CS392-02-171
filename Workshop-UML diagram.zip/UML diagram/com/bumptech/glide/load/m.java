package com.bumptech.glide.load;

import android.content.Context;

/* compiled from: Transformation */
public interface m<T> extends g {
    hi<T> b(Context context, hi<T> hiVar, int i, int i2);
}
