package com.bumptech.glide.load;

/* compiled from: DecodeFormat */
public enum b {
    PREFER_ARGB_8888,
    PREFER_RGB_565;
    
    public static final b c = PREFER_ARGB_8888;
}
