package com.bumptech.glide.load;

/* compiled from: EncodeStrategy */
public enum c {
    SOURCE,
    TRANSFORMED,
    NONE
}
