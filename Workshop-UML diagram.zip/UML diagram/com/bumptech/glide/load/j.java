package com.bumptech.glide.load;

/* compiled from: PreferredColorSpace */
public enum j {
    SRGB,
    DISPLAY_P3
}
