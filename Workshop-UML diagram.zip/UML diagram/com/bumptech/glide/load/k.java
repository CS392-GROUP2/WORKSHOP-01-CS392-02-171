package com.bumptech.glide.load;

import java.io.IOException;

/* compiled from: ResourceDecoder */
public interface k<T, Z> {
    boolean a(T t, i iVar) throws IOException;

    hi<Z> b(T t, int i, int i2, i iVar) throws IOException;
}
