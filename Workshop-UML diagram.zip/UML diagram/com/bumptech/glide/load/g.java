package com.bumptech.glide.load;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import vigqyno.C0201;

/* compiled from: Key */
public interface g {
    public static final Charset a = Charset.forName(C0201.m82(24142));

    void a(MessageDigest messageDigest);

    boolean equals(Object obj);

    int hashCode();
}
