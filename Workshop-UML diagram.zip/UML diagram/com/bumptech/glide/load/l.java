package com.bumptech.glide.load;

/* compiled from: ResourceEncoder */
public interface l<T> extends d<hi<T>> {
    c b(i iVar);
}
