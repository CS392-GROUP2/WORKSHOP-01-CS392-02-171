package com.bumptech.glide;

/* compiled from: Priority */
public enum g {
    IMMEDIATE,
    HIGH,
    NORMAL,
    LOW
}
