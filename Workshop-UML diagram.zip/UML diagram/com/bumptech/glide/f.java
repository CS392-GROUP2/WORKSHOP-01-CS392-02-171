package com.bumptech.glide;

/* compiled from: MemoryCategory */
public enum f {
    LOW(0.5f),
    NORMAL(1.0f),
    HIGH(1.5f);

    private f(float f) {
    }
}
