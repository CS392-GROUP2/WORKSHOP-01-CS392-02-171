package com.bumptech.glide;

/* compiled from: GenericTransitionOptions */
public final class b<TranscodeType> extends l<b<TranscodeType>, TranscodeType> {
}
