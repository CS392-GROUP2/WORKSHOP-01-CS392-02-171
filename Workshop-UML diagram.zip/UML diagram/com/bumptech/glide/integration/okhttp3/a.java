package com.bumptech.glide.integration.okhttp3;

import android.content.Context;
import com.bumptech.glide.c;
import com.bumptech.glide.i;
import com.bumptech.glide.integration.okhttp3.c;
import java.io.InputStream;

/* compiled from: OkHttpLibraryGlideModule */
public final class a extends nn {
    @Override // defpackage.nn
    public void a(Context context, c cVar, i iVar) {
        iVar.r(sj.class, InputStream.class, new c.a());
    }
}
