package com.dylanvann.fastimage;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import com.bumptech.glide.g;
import com.bumptech.glide.load.h;
import com.bumptech.glide.load.m;

/* compiled from: GlideOptions */
public final class i extends ao implements Cloneable {
    /* renamed from: A0 */
    public i P() {
        super.P();
        return this;
    }

    /* renamed from: B0 */
    public i Q(boolean z) {
        return (i) super.Q(z);
    }

    /* renamed from: C0 */
    public i R() {
        return (i) super.R();
    }

    /* renamed from: D0 */
    public i S() {
        return (i) super.S();
    }

    /* renamed from: E0 */
    public i T() {
        return (i) super.T();
    }

    /* renamed from: F0 */
    public i W(int i, int i2) {
        return (i) super.W(i, i2);
    }

    /* renamed from: I0 */
    public i X(Drawable drawable) {
        return (i) super.X(drawable);
    }

    /* renamed from: J0 */
    public i Y(g gVar) {
        return (i) super.Y(gVar);
    }

    /* renamed from: K0 */
    public <Y> i c0(h<Y> hVar, Y y) {
        return (i) super.c0(hVar, y);
    }

    /* renamed from: L0 */
    public i d0(com.bumptech.glide.load.g gVar) {
        return (i) super.d0(gVar);
    }

    /* renamed from: M0 */
    public i e0(float f) {
        return (i) super.e0(f);
    }

    /* renamed from: N0 */
    public i f0(boolean z) {
        return (i) super.f0(z);
    }

    /* renamed from: O0 */
    public i h0(m<Bitmap> mVar) {
        return (i) super.h0(mVar);
    }

    /* renamed from: P0 */
    public i m0(boolean z) {
        return (i) super.m0(z);
    }

    /* renamed from: r0 */
    public i a(vn<?> vnVar) {
        return (i) super.a(vnVar);
    }

    /* renamed from: v0 */
    public i b() {
        return (i) super.b();
    }

    /* renamed from: w0 */
    public i clone() {
        return (i) super.clone();
    }

    /* renamed from: x0 */
    public i d(Class<?> cls) {
        return (i) super.d(cls);
    }

    /* renamed from: y0 */
    public i e(vh vhVar) {
        return (i) super.e(vhVar);
    }

    /* renamed from: z0 */
    public i f(el elVar) {
        return (i) super.f(elVar);
    }
}
