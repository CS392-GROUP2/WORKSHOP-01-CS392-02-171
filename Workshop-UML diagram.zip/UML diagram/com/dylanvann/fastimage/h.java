package com.dylanvann.fastimage;

import android.content.Context;
import android.widget.ImageView;

/* compiled from: FastImageViewWithUrl */
public class h extends ImageView {
    public sj a;

    public h(Context context) {
        super(context);
    }
}
