package com.dylanvann.fastimage;

/* compiled from: FastImageProgressListener */
public interface c {
    float getGranularityPercentage();

    void onProgress(String str, long j, long j2);
}
