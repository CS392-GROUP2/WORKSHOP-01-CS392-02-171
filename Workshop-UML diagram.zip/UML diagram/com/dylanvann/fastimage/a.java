package com.dylanvann.fastimage;

/* compiled from: FastImageCacheControl */
public enum a {
    IMMUTABLE,
    WEB,
    CACHE_ONLY
}
