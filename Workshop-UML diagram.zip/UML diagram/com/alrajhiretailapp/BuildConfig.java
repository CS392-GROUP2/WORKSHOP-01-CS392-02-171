package com.alrajhiretailapp;

import vigqyno.C0201;

public final class BuildConfig {
    public static final String APPLICATION_ID = null;
    public static final String APP_SPECIFIC_PASSWORD = null;
    public static final String BASE_REGISTRATION_URI = null;
    public static final String BASE_URI = null;
    public static final String BASIC_AUTH_PASSWORD = null;
    public static final String BASIC_AUTH_USERNAME = null;
    public static final String BASIC_REGISTRATION_USERNAME = null;
    public static final String BUILD_TYPE = null;
    public static final String DATA_POWER_PROD = null;
    public static final boolean DEBUG = false;
    public static final String ENC_PASSWORD = null;
    public static final String ENC_USERNAME = null;
    public static final String EXTENSION_RELEASE_PROFILE = null;
    public static final String EXTENSION_STAGING_PROFILE = null;
    public static final String FASTLANE_APPLE_APPLICATION_SPECIFIC_PASSWORD = null;
    public static final String GRANT_TYPE = null;
    public static final String GRANT_TYPE_REFRESH = null;
    public static final String IV = null;
    public static final String MARKETPLACE_API_CLIENTID = null;
    public static final String MARKETPLACE_API_SECRET_KEY = null;
    public static final String MARKETPLACE_API_URI = null;
    public static final String MARKETPLACE_ENV = null;
    public static final String MARKETPLACE_IV = null;
    public static final String MARKETPLACE_KEY = null;
    public static final String MARKETPLACE_PAYMENT_ID = null;
    public static final String MARKETPLACE_PAYMENT_PASSWORD = null;
    public static final String METHOD_AUTH = null;
    public static final String MORTGAGE_SIT_URL = null;
    public static final String ONE_TIME_PASSWORD = null;
    public static final String PASSPHRASE = null;
    public static final String PILOT_REG_URL = null;
    public static final String PILOT_REG_URL_V2 = null;
    public static final String PILOT_URL = null;
    public static final String PILOT_URL_V2 = null;
    public static final String PRODUCTION = null;
    public static final String PRODUCTION_REG_URI = null;
    public static final String PRODUCTION_URI = null;
    public static final String PURPOSE = null;
    public static final String RASP = null;
    public static final String RELEASE = null;
    public static final String RELEASE_APPSTORE_USERNAME = null;
    public static final String RELEASE_KEY_ALIAS = null;
    public static final String RELEASE_KEY_PASSWORD = null;
    public static final String RELEASE_PROFILE = null;
    public static final String RELEASE_STORE_FILE = null;
    public static final String RELEASE_STORE_PASSWORD = null;
    public static final String SALT = null;
    public static final String STAGING_KEY_ALIAS = null;
    public static final String STAGING_KEY_PASSWORD = null;
    public static final String STAGING_PROFILE = null;
    public static final String STAGING_STORE_FILE = null;
    public static final String STAGING_STORE_PASSWORD = null;
    public static final int VERSION_CODE = 0;
    public static final String VERSION_NAME = null;
    public static final String __DEV__ = null;

    static {
        C0201.m83(BuildConfig.class, 214);
    }
}
