package com.alrajhiretailapp;

import android.os.Bundle;
import org.devio.rn.splashscreen.c;

public class MainActivitylight extends md2 {
    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public void onCreate(Bundle bundle) {
        w30.i(this);
        c.d(this);
        super.onCreate(bundle);
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onDestroy() {
        w30.k(this);
        super.onDestroy();
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onPause() {
        w30.v(this);
        super.onPause();
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onPostCreate(Bundle bundle) {
        w30.w(this);
        super.onPostCreate(bundle);
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onPostResume() {
        w30.x(this);
        super.onPostResume();
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onRestart() {
        w30.A(this);
        super.onRestart();
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onResume() {
        w30.B(this);
        super.onResume();
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onStart() {
        w30.C(this);
        super.onStart();
    }

    @Override // androidx.fragment.app.d, androidx.activity.ComponentActivity, androidx.core.app.e, androidx.appcompat.app.c, defpackage.md2
    public /* synthetic */ void onStop() {
        w30.D(this);
        super.onStop();
    }
}
