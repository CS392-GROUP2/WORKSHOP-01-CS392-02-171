package com.avishayil.rnrestart;

/* compiled from: ReactInstanceHolder */
public interface a {
    si0 a();
}
